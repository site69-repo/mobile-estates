package admob.plus.cordova.ads;

public interface IAdIsLoaded {
    boolean isLoaded();
}
