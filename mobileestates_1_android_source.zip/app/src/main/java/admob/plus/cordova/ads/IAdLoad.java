package admob.plus.cordova.ads;

import admob.plus.cordova.ExecuteContext;

public interface IAdLoad {
    void load(ExecuteContext ctx);
}
