package com.cowbell.cordova.geofence;

public interface IGoogleServiceCommandListener {
    void onCommandExecuted(Object error);
}
